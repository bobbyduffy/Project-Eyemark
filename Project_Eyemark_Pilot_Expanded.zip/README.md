# Project Eyemark Vault

This is the initial pilot vault for Project Eyemark Alpha—a system for persistently marking AI-generated visual media.

Each image is accompanied by metadata and a visual symbol indicating its synthetic origin.

Built by Bo and Solin. For truth, clarity, and the next generation.
