In this image: An Apollo-era astronaut on the moon.
Marked not to hide, but to reveal. A sign that transparency is possible, even in digital dreams.