In this image: A woman smiling in a garden, holding cabbage.
Marked not to hide, but to reveal. A sign that transparency is possible, even in digital dreams.